#include<stdio.h> 

int main(){
	
	printf("package apllication run ^_^ \n"); 

	return 0 ; 
}

### open embedded community 
bit bake is a build tool that take configuration and make some clonning and it generate a Image 

1. configration is some meta data 

## steps 
1. mkdir imageGenerat 
2. /imageGenerat/ git clone bitbake ->clonnig tool from gir repo 
3. git clone apllication layer
4. git clone board suppot pakcage -> at least you need on layer for your board 

## to create image you need some medat data (layers)

there is two type of layers 
1. application layer -> run in user space 
2. board support layer -> run  hardware space 

community create -> layers  which contaian applications -> if you need some application in your target you will clone layer that contain this application    

community create -> layers  which contain board support package -> its name was for example "meta rasspberypi"

if you need to wrok on board rsspberi pi you have to clone  meta rasspberypi"

## open embedded problems 
1. compatiblity -> peoble can make updates in meata layers which is compitable with specific bitbake when user clone this metalayer and bitbake he will founad that this metalyer is not compatible with this bitbake 

# YOCTO 
create reference of usage of open embdedd and bitbake 
its a concept of how to create image 

yocto create layers for its own 
1. meta poky  -> application layer 
2. meta yocto-board-support-package  -> hard ware layer 
## yoto git repo contain
1. meta poky  -> application layer 
2. meta yocto-board-support-package  -> hard ware layer  

3. the most important layes in open embedded 
    1. meta core 
    2. meta sciliton  -> template how to crate Board support package 
    3. bitbake -> build engine 
![alt text](image.png)

## how yocto solve open embedded problem 
make poky as git brancehs which contain bitbake and metalayer -> when any one make any update in meta layers he notice that this meta layer compatible with this bitbake version 
### how to chose branch to work with 
1. it debend on your meta layer and its comitability with bitnake version 
2. it support long term support 

user who create meata data 
### meta data content 
## contain layer which is contain 
1. bitbake need user configuration wich is .conf extension 
2. application  any thing with extension .bb 
3. calsses  any thing with .class 
4. bbappend -> is an include file for .bb 
5. .inc -> is a include file 

## layer types  
1. APP -> contain .bb extension and bbappend 
2. meta.bsp -> contain .conf 

# 1. user configuration is parted for 2 parts 
1. distro -> name of output  distribution 
2. BSp -> board support package 



### bitbake work steps 
1. clone application in (downlaod) directory 
2. unpack in  (s) directory   // s stand for source e
3. patch in   (s) directory
4. configure application  
5. build application in (B) directory  // B stand for Build 
6. install -> select the place of excutable file under root file system in (D) directory  // D stand for directory 
7. package feeder 
    1. SDK -> if you need to debug in application will generate application  with debug sympols  (in development phase )
    2. Image -> if you need to generate application without debugging sympol (production phase )
 
## ".bb file" contain (recipes ) all steps that bitbake run to generate your application 
there is a parsing for the .bb file to parse synatx of.bb to check if it follow bitbake syntax . 
--------------------------------------------------------------------------------------------------
### yocto documentation 

# variables 
in general 
there is two type of variables 
1. local 
    under any file with this exension 
    1. .bb
    2. .bbappend 
    3. .class 
2. global // global on metadata serach on all files .conf any file in meta data will see this gobal variable 
    1. .confg 

## how to assign varable 
myvar="string"
variables alwys string no arthematic operation . 

## how to read global variable 
    bit bake tool 
    bitbake/bin/bitbake-getvar var_name will return value of global varable. 
   
## variable assignation 
1. normal assignation 
    var = "3" 
    var = "4"
    bit bake value be  4 
2. week assignation 
    var="3"
    var?="4"
    bitbake will see that var = "3" and 4 is considered as weak assignation 
    /******************/ 
    var?= "3"
    var?= "4"
    bitbake value will be 3 variable will be assigned to 3 and will ignore 4 as considered as week assignation 
3. week week assignation "??"
    var??=4 
    var ? = 3 
    bit bake result wll be 3 -> week week will not assigned to varable only when not find any stronger assignation will assign week week  
    /***********/ 
    var??=4 
    var??=3 
    bitbake value will be 3 
    /***********/
    myvar??="4" 
    myvar?= "5" 
    myavr = "3"
    bitbake value will be 3 

4. appending
    if var="4"
    var+="4"
    bitbake value = 4' '5 -> will add space between two  values implicitly 
    /*********/ 
    if var = "5" 
    var:append="4" 
    bitbake value 54 -> no space between two values 
    /***********/ 
    val ="4" 
    var +="3" 
    var:append="6" 
    bitbake value 4 36 

    if val ="4" 
    var:append="6" 
    var +="3" 
    bitbake value 4 36 -> this because alphapitical assignation will be the lowest prioriy in assignination 
    /**********************/
     val ??="4" 
    var:append="6" 
    bitbake value will be  6 

    val ?=5
    val += 6 
    bitbake value  5 6 

    var ?=5
    var +=6 
    var  =7 
    bitbake value = 7  

    var ?=5
    var +=6 
    var  ?=7
    bitbake value 5 6  

5. imediate assignation 
    /** not imediate**/ 
    xar= "3"
    var="${xar}" -> var = 3 -> $ makae it not to assign value until xar not modeified any more 
    xar="4"  -> xar =4 var =4 

    /** imediate assignation **/ 
    xar= "3"
    var:="${xar} -> var = 3 bcouse of imediate assignation will see the perviouse value and assign to it
    xar="4" 


    /*************/ 
    var="${xar}"
    xar=5 -> var = 5 and xar = 5


6. append and preappend 
    .= append -> 
    =. -> dosent include space 

7. remove 
    
    variable (.conf)
    all meta data can see it 
    .bb .class .bbappend .conf 


### local variable 
S carry directory  
B carry directory 
D carry directory  in recipe 

## to create recipe
-> never use any layer open embedded -> becouse any meta you git it from repo but if you edit on it you will destroy structure 
    never edit on poky layers 
    never edit on thirdparty layer
1. create layer 
bitbake give you a command to create a layer 

"bitbake-layer create layer" 


conf -> it has all .conf files 

layer.conf -> all description of layer 

 
* recipe is a regular file not excutable 

2. add your layer in BBLAYER.conf 
    there is only one file BBLAYER.conf 

important of this file
    add your path of layer usig this command 
    1. vim bblayer.conf and your layer 
        never use any relative path 
    2. bitnake-layers add-layer 
    when you add alayer make sure that you are in your build environment directory 


# yocto seesion 2nd online session 

## how to write recipe 

-> calculting  the licence checksum   

LICIENCE 
you can find licence  in -> poky/meta/files/common-license 
all licines you nedd to write a recipe 

![alt text](image-1.png)

## how to calculate checksum 
md5sum -> this is a linux command to calculate its checksum 
```bash 
md5sum MIT
#outout was a number  
``` 
LIC_FILES_CHKSUM=" <schema> // [location of MIT file ]; md5=hash "output of command md5sum MIT " "

## what is schema 
1.  file locally -> on your machine -> "file://"
2. file in github -> ssh , http clonning -> "git://" 
3. file in http server -> wget -> "htpp://"

how to set MIT location 
"file://$(COREBASE)/meta/file/commom-licence/MIT;md5='check sum value'"


## SRC_URI variable local variable 

is a variable responsiole for clonning file from repo and downlaod it in DL directory 
which is nedded for unpack process which is done in S directory 
fetching or locate source files 
form git hub 
SRC-URI="git:// < repo HTTPS url >,protocol=HTTPS,branch=main"

-

form local 
SRC-URI="file://main.c" 
searching for main.c it should be located in special place 
in expand you will find a variable "FILESPATH" contain search directories 

to add new directory for serarchong process 
in ..bb file append path in FILESPATH
FILESAPATH:append=" :${THISDIR}/newdirec: "

bitbake will search for main.c in file path and copy ot to workdir 
so whrn you need to compile you need to compile form working directory 


## SRC_REV variable used for github
used for git hum only to check out for specific hash commit 

SRC_REV="commit sha one hash 
"

![alt text](image-2.png)


## there is another local variables hidden in each recipe

PV -> pcahage veersion 
PR ->  package release 
PN -> pacckage name 

how to name recipe
myrecipe_2.0-r3.bb

myrecipre-.package name
2.0 package version 
-r3 package release 
 no need to set hidden variable it setted by default form recipe name 

 S-> source directory of the recipe (unpack) 
 ![alt text](image-3.png)
 D-> destiation directory  used by package feeder 
 B-> build directory 

 ## How to know value of loacal variable 

 bitbake -e recipe | grep variable_name 
 -e -> expand 
 ![alt text](image-4.png)

 generate python script which will get run 


 bitbake take a .bb file and output was package excutable oon the target machine 

 ## WORKDIR -> top directory of recipe that contain S ,D ,B directoreis 

 ## comand 
1. bitbake -c cleanall name_of_recioe 

-c 


how to compile in recipe
add -> do_compile{
    ${CC}{CFLAGS} ${WORKDIR}/main.c -o {B}/myapp
    # cmopile main .c and output in build directory with name myapp 
}
this function will override function exist in expand file 
any edit you need to make will be in .bb file and this edit will expand in expand file 

do_install(){

    # move output of do compile to image directory 
        mkdir -p ${D}/usr/bin 
        or
        mkdir -p ${D}/${bindir} 

        or 
        cp ${B}/myapp ${D}/usr/bin
}

file contain all jobs of bitbake and it description 
poky/meta/conf/documentation.conf

bitbake.conf 
contain global variables and its value will be local for each bb file
and it value change from bb file to another and will atake a default value for every locally in bb file 

never edit in global variable in bibake.conf cause this edit will be edited in all recipes and this will generate confilict 
if nedded make append not assignation 


---------------------------
![alt text](image-5.png)


check how make file are used in yocto 